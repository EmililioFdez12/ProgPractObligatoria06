package prog.ud06.actividad611.coleccion.diccionario;

import java.io.Serializable;

public class DiccionarioException extends RuntimeException implements Serializable {
    public DiccionarioException(){
    
    }
}
