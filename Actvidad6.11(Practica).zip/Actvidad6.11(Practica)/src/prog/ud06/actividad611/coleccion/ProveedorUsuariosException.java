package prog.ud06.actividad611.coleccion;

public class ProveedorUsuariosException extends Exception {

  private static final long serialVersionUID = 1L;

}
