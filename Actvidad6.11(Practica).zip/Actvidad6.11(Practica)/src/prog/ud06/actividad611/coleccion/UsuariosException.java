package prog.ud06.actividad611.coleccion;

import java.io.Serializable;

public class UsuariosException extends RuntimeException implements Serializable {

}
